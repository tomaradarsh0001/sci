@extends('frontend.layouts.main')
@section('main-container')
@section('define_robots', 'index, follow')
@section('define_urltype', 'website') @section('ob_img', 'https://scihospital.com/public/assets/images/sci%20logo.webp')


</head>
<body>
    
    
  
<div class="page-content">
    <!--section-->
    <div class="section mt-0">
        <div class="container-fluid">
            <div class="row">
                <img src="{{asset('public/assets/images/doctors/SCI-Doctors.jpg')}}" class="img-fluid" alt="" />
            </div>
        </div>
    </div>
    <!--//section-->
    <!--section-->
    <div class="section mt-0" id="doctor">
        <div class="breadcrumbs-wrap">
            <div class="container">
                <div class="breadcrumbs">
                    <a href="{{ route('/') }}">Home</a>
                    <a href="#">Our Doctors</a>
                    <span>Dr. Raj Kumar Singh</span>
                </div>
            </div>
        </div>
    </div>
    <!--//section-->
    <!--section-->
    <div class="section page-content-first pb-70">
        <div class="container mt-6">
            <div class="row">
                <div class="container doctor_details_section">
                    <div class="row align-items-center">
                        <div class="col-lg-3 col-md-3">
                            <div class="doctor_img_detail">
                                <img src="{{asset('public/assets/images/doctors/dr_raj.png')}}" class="img-fluid" alt="" />
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <h5 class="doctor-box-name mb-2  theme-color">Dr Raj Kumar Singh</h5>
                          
                            <p class="degree_section"> Visiting Consultant  <br> Laparoscopic General Surgeon</p>
                            <ul class="list_details_doc">
                                <li><i class="fa fa-map-marker"></i> M 4, Greater Kailash-1, M Block, part-1, Greater Kailash, New Delhi, Delhi 110048</li>
                                <li><i class="fa fa-phone"></i> Mobile: +91-9999446622</li>
                                <li><i class="fa fa-envelope"></i> Email: info@scihospital.com</li>
                            </ul>
                        </div>
                        <div class="col-lg-3 col-md-3 text-center">
                            <div class="call_box">
                                <p><i class="fa fa-phone"></i></p>
                                <p class="app_doc">For Appointment, call us on</p>
                                <p><a href="tel:9999446622">+91-9999446622</a></p>
                            </div>
                        </div>
                    </div>
                    <hr />
                    <div class="row align-items-center">
                        <div class="col-lg-12">
                            <div class="tab_doctors">
                                <div class="tab_home row nav nav-pills-icons js-doc-carousel" role="tablist">
                                    <a class="nav-link active" data-toggle="pill" href="#tab-A" role="tab"><i class="fa fa-university"></i> EDUCATION</a>
                                    <a class="nav-link" data-toggle="pill" href="#tab-B" role="tab"><i class="fa fa-trophy"></i> AREAS OF EXPERTISE</a>
                                    <a class="nav-link" data-toggle="pill" href="#tab-C" role="tab"><i class="fa fa-users"></i> MEMBERSHIPS </a>
                                    <!--<a class="nav-link" data-toggle="pill" href="#tab-D" role="tab"><i class="fa fa-graduation-cap"></i> FELLOWSHIP</a>-->
                                    <!--<a class="nav-link" data-toggle="pill" href="#tab-E" role="tab"><i class="fa fa-leanpub"></i> PUBLICATION</a>-->
                                </div>
                                <div id="tab-content" class="tab-content mt-2">
                                    <div id="tab-A" class="tab-pane fade in active" role="tabpanel">
                                        <div class="row">
                                            <div class="col-md-12 h-100">
                                                <p>MBBS in 2007, from  Vardhman Mahavir Medical College & Safdarjung Hospital, New Delhi. 

                                           MS (General Surgery), in 2012 from Vardhman Mahavir Medical College & Safdarjung Hospital, New Delhi.  </p>
                                           <p>Trained as General, Laparoscopic and Oncosurgery under the guidance of professor surgeon, in Vardhman Mahavir Medical College & Safdarjung Hospital, New Delhi, as SENIOR RESIDENT. </p>
                                                <p>FIAGES (Fellowship - Indian Association of Gastrointestinal Endo Surgeons ) </p>
                                                <p>FMAS (Fellowship in Minimal Access Surgery ) </p>
                                                <p>Member of International College Laparoscopic  Surgeon (MCLS) </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="tab-B" class="tab-pane fade" role="tabpanel">
                                        <div class="row">
                                            <div class="col-md-12 h-100">
                                                <p>
                                                              Expertise in LASER for piles, fissure and fistula,  LASER treatment for varicose vein (EVLT). 
                                          </p>

<p>Performed Minimal Invasive procedures such as Cholecystectomy, Appendectomy, Inguinal and Incisional   Hernia through SILS (SINGLE INCISION LAPAROSCOPIC SURGERY)etc. 
 </p>
<p>Expertise in LASER Liposuction for Gynaecomastia & Abdominal Fat. 
 </p>

<p>Performed minor and outpatient surgical procedures such as cyst excision, breast mass biopsy, chest tube thoraco-tomy , and tracheostomy insertion. 
 </p>
<p>Operated on emergency (trauma) surgical procedures  , Exploratory Laparotomy.
 </p>
 

<p>Diagnosed medical conditions that warranted general surgery and other related treatments. 
</p>      
 
                                            </div>
                                        </div>
                                    </div>
                                    <div id="tab-C" class="tab-pane fade" role="tabpanel">
                                        <div class="row">
                                            <div class="col-md-12 h-100">
                                          
                                          <p>Delhi Medical Council (DMC) </p>

<p>The Association of Surgeons of India (ASI)  </p>

<p>Association of Minimal Access Surgeons of India (AMASI)  </p>

<p>Indian Association of Gastrointestinal Endo Surgeons (IAGES)  </p>

<p>Indian Medical Association (IMA)  </p>
 
<p>
Indian Hernia Society (IHS) </p>
<p>Society of Endoscopic and Laparoscopic Surgeons of India (SELSI)  </p>

<p>Member of International College Laparoscopic  Surgeon (MCLS)  </p>

                                            </div>
                                        </div>
                                    </div>
                                    <!--<div id="tab-D" class="tab-pane fade" role="tabpanel">-->
                                    <!--    <div class="row">-->
                                    <!--        <div class="col-md-12 h-100">-->
                                    <!--            <p>6 weeks Observership in Advance reconstructive uro-genital surgery at Sava Perovic Foundation, Belgrade Serbia.</p>-->
                                    <!--            <p>Trained in Reconstructive Urology from Pune, India.</p>-->
                                    <!--        </div>-->
                                    <!--    </div>-->
                                    <!--</div>-->
                                    <!--<div id="tab-E" class="tab-pane fade" role="tabpanel">-->
                                    <!--    <div class="row">-->
                                    <!--        <div class="col-md-12 h-100">-->
                                    <!--            <p>Paper presentation title-“Detrusor Ultrastructure-Its correlation with clinical outcome in patient with bladder outlet obstruction.” at USICON-2010 Agra</p>-->
                                    <!--            <p>Paper presentation title-“Outcome of Percutaneous Nephrolithotomy (PCNL) in patient with history of renal surgery.” at NZUSICON 2009 Amritsar</p>-->
                                    <!--            <p>Paper presentation title-“Long term outcome of perineal anastomotic urethroplasty for managing post-traumatic urethral strictures in children.” at USICON-2009 Indore</p>-->
                                    <!--            <p>-->
                                    <!--                Poster presentation title “Prognostic and predictive significance of PSA kinetics in advanced prostate cancer after initial androgen deprivation therapy” in Asian Congress of Urology-2008-->
                                    <!--                New Delhi-->
                                    <!--            </p>-->
                                    <!--            <p>Progress session-“augmented Reality-The next level of surgical accuracy” in NZUSICON 2008 Allahabad</p>-->
                                    <!--            <p>Paper presentation title-“Outcome of valve ablation in late-presenting posterior urethral valves.” at NZUSICON 2008 Allahabad</p>-->
                                    <!--        </div>-->
                                    <!--    </div>-->
                                    <!--</div>-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--//section-->
</div>

@endsection
